if test -f /home/gitpod/.android/repositories.cfg; then
   mkdir /home/gitpod/.android
   touch /home/gitpod/.android/repositories.cfg
fi
export 'ANDROID_SDK_ROOT'="/home/gitpod/android-sdk"
echo "sdk.dir=$ANDROID_SDK_ROOT" > local.properties
if ! test -d "$ANDROID_SDK_ROOT" ; then
   mkdir -p "$ANDROID_SDK_ROOT"
fi
cd "$ANDROID_SDK_ROOT"
if ! test -d "$ANDROID_SDK_ROOT/cmdline-tools/latest"; then
    curl -o cmd_line_tools.zip  "https://dl.google.com/android/repository/commandlinetools-linux-6604631_latest.zip"
    unzip -q cmd_line_tools.zip
    mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools/latest"
    mv cmdline-tools/* cmdline-tools/latest
    rm -f cmd_line_tools.zip 
    yes | "$ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" --licenses
fi
cd /workspace/FtcRobotController/
chmod +x gradlew
if test -f 'ftc2020_baseline.zip'; then
   unzip -o 'ftc2020_baseline.zip'
   rm 'ftc2020_baseline.zip'
fi
if test -f 'gitpod_prep.zip'; then
   unzip -o 'gitpod_prep.zip'
   rm 'gitpod_prep.zip'
fi
./gradlew build